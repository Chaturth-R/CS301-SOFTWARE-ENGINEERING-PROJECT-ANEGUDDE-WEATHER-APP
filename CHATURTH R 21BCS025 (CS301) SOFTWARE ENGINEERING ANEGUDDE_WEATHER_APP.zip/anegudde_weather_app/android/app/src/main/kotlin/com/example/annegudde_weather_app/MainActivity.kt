package com.example.annegudde_weather_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
