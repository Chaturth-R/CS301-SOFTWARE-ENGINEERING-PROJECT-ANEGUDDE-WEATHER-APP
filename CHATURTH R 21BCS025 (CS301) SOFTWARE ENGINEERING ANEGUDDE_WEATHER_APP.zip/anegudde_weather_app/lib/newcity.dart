import 'dart:convert';

import 'package:annegudde_weather_app/ApiConstants.dart';
import 'package:annegudde_weather_app/shared_prefs.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:http/http.dart' as http;
import 'package:weather_icons/weather_icons.dart';

class Newcity extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Login',
      home: NewcityPage(),
      theme: ThemeData(
          primarySwatch: Colors.blue,
          fontFamily: 'Poppins'
      ),
    );
  }
}

class NewcityPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return Newcitystate();
  }
}

class Newcitystate extends State<NewcityPage> {
  final citycontrol = TextEditingController();
  late var cityDetails = null;
  bool detailsVisible = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        title: Text(
          'New City Weather',
          style: TextStyle(
            fontSize: 15.0,
          ),
        ),
      ),

      body: Column(
        children: [
          Container(
            margin: EdgeInsets.all(5.0),
            child: Form(
                child: TextFormField(
                  controller: citycontrol,
              decoration: InputDecoration(
                hintText: 'City Name',
                prefixIcon: Icon(Icons.my_location_rounded),
                prefixIconColor: Colors.blue,
                border: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.red,
                  ),
                  borderRadius: BorderRadius.circular(5.0),
                ),
              ),
            )),
          ),
          Container(
            width: double.infinity,
            height: 50,
            margin: EdgeInsets.all(5.0),
            child: ElevatedButton.icon(
              icon: Icon(Icons.download_outlined),
              label: Text('Get Weather Info'),
              onPressed: () {
                getCityData();
              },
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all(Colors.blue),
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.all(10.0),
            child:
            ( detailsVisible ?
              SingleChildScrollView(
                child: Column(
                  children: [
                    Card(
                      child: Padding(
                        padding: EdgeInsets.all(20.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.location_on_outlined, color: Colors.grey),
                            SizedBox(width: 5.0),
                            Text(
                              cityDetails['location']['name'].toString() + ", " +
                              cityDetails['location']['region'].toString(),
                              style: TextStyle(
                                  color: Colors.black, fontSize: 14, fontWeight: FontWeight.w600, letterSpacing: 1.0),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Card(
                      child: Padding(
                        padding: EdgeInsets.all(15.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Image.network(
                                  "https:" + cityDetails['current']['condition']['icon'].toString(),
                                  color: Colors.blue,
                                ),
                                SizedBox(width: 5.0),
                                Text(
                                  cityDetails['current']['condition']['text'].toString(),
                                  style: TextStyle(
                                      color: Colors.black, fontSize: 15, fontWeight: FontWeight.w600, letterSpacing: 1.0),
                                ),
                              ],
                            ),
                            Text(
                              cityDetails['current']['temp_c'].toString(),
                              style: TextStyle( color: Colors.black, fontSize: 20),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Card(
                      child: Padding(
                        padding: EdgeInsets.all(20.0),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Icon(
                                      size: 50,
                                      Icons.air,
                                      color: Colors.blue,
                                    ),
                                    SizedBox( width: 10.0 ),
                                    Column(
                                      children: [
                                        Text(
                                          'Wind Direction',
                                          style: TextStyle(
                                              color: Colors.black, fontSize: 15, fontWeight: FontWeight.bold),
                                        ),
                                        SizedBox(
                                          height: 5.0,
                                        ),
                                        Text(
                                          cityDetails['current']['wind_kph'].toString() + "km/h",
                                          style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 12,
                                            fontWeight: FontWeight.w400,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                Text(
                                  cityDetails['current']['wind_dir'].toString(),
                                  style: TextStyle(
                                      color: Colors.blue, fontSize: 15, fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    GridView.count(
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      crossAxisCount: 2,
                      childAspectRatio: (1 / .5),
                      children: [
                        Card(
                          child: Padding(
                            padding: EdgeInsets.all(20.0),
                            child: Row(
                              children: [
                                Icon(
                                  size: 40,
                                  Icons.water_drop,
                                  color: Colors.blue,
                                ),
                                SizedBox( width: 10.0 ),
                                Column(
                                  children: [
                                    Text(
                                      cityDetails['current']['humidity'].toString() + "%",
                                      style: TextStyle(
                                          color: Colors.black, fontSize: 15, fontWeight: FontWeight.bold),
                                    ),
                                    Text(
                                      'Humidity',
                                      style: TextStyle( color: Colors.black, fontSize: 10, fontWeight: FontWeight.w400,),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                        Card(
                          child: Padding(
                            padding: EdgeInsets.all(20.0),
                            child: Row(
                              children: [
                                Icon(
                                  size: 40.0,
                                  WeatherIcons.celsius,
                                  color: Colors.blue,
                                ),
                                SizedBox( width: 10.0 ),
                                Column(
                                  children: [
                                    Text(
                                      cityDetails['current']['feelslike_c'].toString() + " C",
                                      style: TextStyle(
                                          color: Colors.black, fontSize: 15, fontWeight: FontWeight.bold),
                                    ),
                                    Text(
                                      'Real Feel',
                                      style: TextStyle( color: Colors.black, fontSize: 10, fontWeight: FontWeight.w400,),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                        Card(
                          child: Padding(
                            padding: EdgeInsets.all(20.0),
                            child: Row(
                              children: [
                                Icon(
                                  size: 40,
                                  Icons.sunny,
                                  color: Colors.blue,
                                ),
                                SizedBox( width: 10.0 ),
                                Column(
                                  children: [
                                    Text(
                                      cityDetails['current']['uv'].toString(),
                                      style: TextStyle(
                                          color: Colors.black, fontSize: 15, fontWeight: FontWeight.bold),
                                    ),
                                    Text(
                                      'UV',
                                      style: TextStyle( color: Colors.black, fontSize: 10, fontWeight: FontWeight.w400,),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                        Card(
                          child: Padding(
                            padding: EdgeInsets.all(20.0),
                            child: Row(
                              children: [
                                Icon(
                                  size: 40,
                                  Icons.arrow_downward,
                                  color: Colors.blue,
                                ),
                                SizedBox( width: 10.0 ),
                                Column(
                                  children: [
                                    Text(
                                      cityDetails['current']['pressure_mb'].toString() + " mb",
                                      style: TextStyle(
                                          color: Colors.black, fontSize: 15, fontWeight: FontWeight.bold),
                                    ),
                                    Text(
                                      'Pressure',
                                      style: TextStyle( color: Colors.black, fontSize: 10, fontWeight: FontWeight.w400,),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    // Card(
                    //   child: Padding(
                    //     padding: EdgeInsets.all(20.0),
                    //     child: Column(
                    //       children: [
                    //         Row(
                    //           mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    //           children: [
                    //             Text(
                    //               'Sunrise',
                    //               style: TextStyle(
                    //                   color: Colors.black, fontSize: 15, fontWeight: FontWeight.bold),
                    //             ),
                    //             Text(
                    //               cityDetails['forecast']['forecastday'][0]['astro']['sunrise'].toString(),
                    //               style: TextStyle(
                    //                   color: Colors.black, fontSize: 12, fontWeight: FontWeight.w400),
                    //             ),
                    //           ],
                    //         ),
                    //         SizedBox( height: 20.0 ),
                    //         Row(
                    //           mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    //           children: [
                    //             Text(
                    //               'Sunset',
                    //               style: TextStyle(
                    //                   color: Colors.black, fontSize: 15, fontWeight: FontWeight.bold),
                    //             ),
                    //             Text(
                    //               cityDetails['forecast']['forecastday'][0]['astro']['sunset'].toString(),
                    //               style: TextStyle(
                    //                   color: Colors.black, fontSize: 12, fontWeight: FontWeight.w400),
                    //             ),
                    //           ],
                    //         ),
                    //       ],
                    //     ),
                    //   ),
                    // ),
                  ],
                ),
              )
              : Center(
                child: Text('no data available'),
              )
            ),
          ),
        ],
      ),
    );
  }

  getCityData() async {
    if(citycontrol.text.isNotEmpty){
      final urlParams = ApiConstants().getNewCityParams(citycontrol.text);
      final weatherurl = ApiConstants.baseUrl + urlParams;
      final ApiResponse = await http.get(Uri.parse(weatherurl));
      cityDetails = json.decode(ApiResponse.body);
      setState(() {
        detailsVisible = true;
      });
    } else {
      setState(() {
        detailsVisible = false;
      });
    }
  }
}
