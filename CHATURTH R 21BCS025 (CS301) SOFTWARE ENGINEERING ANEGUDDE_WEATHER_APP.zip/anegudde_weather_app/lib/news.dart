import 'package:annegudde_weather_app/models/NewsData.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class News extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Latest News',
      home: NewsPage(),
      theme: ThemeData(
          primarySwatch: Colors.blue,
          fontFamily: 'Poppins'
      ),
    );
  }
}

class NewsPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return NewsPageState();
  }
}

class NewsPageState extends State<NewsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Latest News',
          style: TextStyle(
            fontSize: 15.0,
          ),
        ),
      ),
      body: Container(
        child: FutureBuilder<List>(
            future: getNewsData(),
            builder: (context, snapshot) {
              if(snapshot.hasData){
                return ListView.builder(
                    itemCount: snapshot.data!.length,
                    itemBuilder: (context, index) {
                      List newsData = snapshot.data!;
                      return Card(
                        child: Padding(
                          padding: EdgeInsets.all(20.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Image.asset(
                                newsData[index].imageUrl,
                                height: 150,
                                width: 400,
                                fit: BoxFit.fill
                              ),
                              SizedBox(height: 10.0),
                              Text(
                                newsData[index].title,
                                style: TextStyle(
                                    color: Colors.black, fontSize: 15, fontWeight: FontWeight.w600),
                              ),
                              SizedBox(height: 5.0),
                              Text(
                                newsData[index].description,
                                style: TextStyle(
                                    color: Colors.black, fontSize: 12),
                              ),
                              SizedBox(height: 10.0),
                              InkWell(
                                onTap: () => viewMoreAction(newsData[index].sourceUrl),
                                child: Text(
                                  'View More',
                                  textAlign: TextAlign.right,
                                  style: TextStyle(color: Colors.blue),
                                ),
                              )
                            ],
                          ),
                        ),
                      );
                    }
                );
              }
              return Center(
                child: CircularProgressIndicator(
                  color: Colors.blue,
                ),
              );
            }
        ),
      ),
    );
  }

  viewMoreAction(String url) async {
    final uri = Uri.parse(url);
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  Future<List> getNewsData() async {
    List<NewsData> newsList = [];

    newsList.add(
      const NewsData(
            imageUrl: 'detailed_forecast.jpg',
            title: 'Typical Pre Monsoon rains over South India',
            description: 'South India is all set to see the typical Pre Monsoon activities for the next four to five days.',
            sourceUrl: 'https://www.skymetweather.com/content/weather-news-and-analysis/typical-pre-monsoon-rains-over-south-india/',
            date: '2023-03-31'
      ),
    );
    newsList.add(
      const NewsData(
          imageUrl: 'forecast.jpg',
          title: 'Telangana, Andhra, Karnataka, Tamil Nadu In for Rains and Thunderstorms',
          description: 'The met department has advised farmers to take necessary measures to protect their crops and livestock from inclement weather.',
          sourceUrl: 'https://youtu.be/sxN3pZ8gaN4',
          date: '2023-03-31'
      ),
    );

    return newsList;
  }
}
