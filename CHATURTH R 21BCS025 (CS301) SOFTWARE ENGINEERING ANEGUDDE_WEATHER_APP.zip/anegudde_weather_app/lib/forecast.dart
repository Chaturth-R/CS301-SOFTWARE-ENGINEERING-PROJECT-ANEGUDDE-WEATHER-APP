import 'dart:convert';

import 'package:annegudde_weather_app/models/ForecastDayModel.dart';
import 'package:annegudde_weather_app/shared_prefs.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'ApiConstants.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

import 'package:weather_icons/weather_icons.dart';

class Forecast extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ForecastPage();
  }
}

class ForecastPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return ForecastState();
  }
}

class ForecastState extends State<ForecastPage> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Forecaste',
      theme: ThemeData(
          primarySwatch: Colors.blue,
          fontFamily: 'Poppins'
      ),
      home: DefaultTabController(
        length: 3,
        child: Scaffold(
          appBar: AppBar(
            title: Text(
              'Forecast',
              style: TextStyle(
                fontSize: 15.0,
              ),
            ),
            bottom: TabBar(
              tabs: [
                Tab(
                  child: Text('24 Hours'),
                ),
                Tab(
                  child: Text('Week'),
                ),
                Tab(
                  child: Text('Detailed'),
                ),
              ],
            ),
          ),
          body: TabBarView(
            children: [
              Container(
                child: Container(
                  margin: EdgeInsets.all(5.0),
                  child: FutureBuilder<List>(
                      future: getForecastHourData(),
                      builder: (context, snapshot) {
                        if (snapshot.connectionState ==
                            ConnectionState.waiting) {
                        } else if (snapshot.connectionState ==
                            ConnectionState.done) {
                          return GridView.builder(
                              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3),
                              itemCount: snapshot.data![0]["hour"].length,
                              itemBuilder: (context, index) {
                                List currentdayhour = snapshot.data![0]["hour"];
                                final time=currentdayhour[index]["time"].toString().split(" ")[1];
                                // if (time >=12 )
                                return Card(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Image.network(
                                        "https:" + currentdayhour[index]["condition"]['icon'].toString(),
                                        color: Colors.blue,
                                      ),
                                      Text(
                                        currentdayhour[index]["temp_c"].toString(),
                                        style: TextStyle(
                                            color: Colors.black, fontSize: 15, fontWeight: FontWeight.bold),
                                      ),
                                      Text(
                                        time.toString(),
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 10,
                                          fontWeight: FontWeight.w200,
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              });
                        }
                        return Center(
                          child: CircularProgressIndicator(
                            color: Colors.blue,
                          ),
                        );
                      }),
                ),
              ),
              Container(
                child: Container(
                  margin: EdgeInsets.all(5.0),
                  child: FutureBuilder<List>(
                      future: getForecastHourData(),
                      builder: (context, snapshot) {
                        if (snapshot.connectionState ==
                            ConnectionState.waiting) {
                        } else if (snapshot.connectionState ==
                            ConnectionState.done) {
                          return ListView.builder(
                              itemCount: snapshot.data!.length,
                              itemBuilder: (context, index) {
                                List currentday = snapshot.data!;
                                var currentDate = DateTime.parse(currentday[index]['date']);
                                var formatCurrentdate = DateFormat('EEEE').format(currentDate);
                                // if (time >=12 )
                                return Card(
                                  child: Column(
                                    children: [
                                      Padding(
                                        padding: EdgeInsets.only(right: 20.0),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Image.network(
                                              "https:" + currentday[index]['day']['condition']['icon'].toString(),
                                              color: Colors.black,
                                            ),
                                            Text(
                                              ( index == 0 ? 'TODAY' : formatCurrentdate.toUpperCase() ),
                                              style: TextStyle(
                                                  color: Colors.black, fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 3.0),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        height: 150,
                                        child: ListView.builder(
                                          scrollDirection: Axis.horizontal,
                                          shrinkWrap: true,
                                          itemCount: currentday[index]["hour"].length,
                                          itemBuilder: (c, i) {
                                            List currentdayhour = currentday[index]["hour"];
                                            final time=currentdayhour[i]["time"].toString().split(" ")[1];
                                            return Card(
                                              child: Column(
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children: [
                                                  Image.network(
                                                    "https:" + currentdayhour[i]["condition"]['icon'].toString(),
                                                    color: Colors.blue,
                                                  ),
                                                  Text(
                                                    currentdayhour[i]["temp_c"].toString(),
                                                    style: TextStyle(
                                                        color: Colors.black, fontSize: 15, fontWeight: FontWeight.bold),
                                                  ),
                                                  Text(
                                                    time.toString(),
                                                    style: TextStyle(
                                                      color: Colors.black,
                                                      fontSize: 10,
                                                      fontWeight: FontWeight.w200,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            );
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              });
                        }
                        return Center(
                          child: CircularProgressIndicator(
                            color: Colors.blue,
                          ),
                        );
                      }),
                ),
              ),
              Container(
                child: Container(
                  margin: EdgeInsets.all(10.0),
                  child: FutureBuilder(
                      future: getWeatherDetails(),
                      builder: (context, snapshot) {
                        if (snapshot.connectionState ==
                            ConnectionState.waiting) {
                        } else if (snapshot.connectionState ==
                            ConnectionState.done) {
                          return SingleChildScrollView(
                            child: Column(
                              children: [
                                Card(
                                  child: Padding(
                                    padding: EdgeInsets.all(20.0),
                                    child: Column(
                                      children: [
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Row(
                                              children: [
                                                Icon(
                                                  size: 50,
                                                  Icons.air,
                                                  color: Colors.blue,
                                                ),
                                                SizedBox( width: 10.0 ),
                                                Column(
                                                  children: [
                                                    Text(
                                                      'Wind Direction',
                                                      style: TextStyle(
                                                          color: Colors.black, fontSize: 15, fontWeight: FontWeight.bold),
                                                    ),
                                                    SizedBox(
                                                      height: 5.0,
                                                    ),
                                                    Text(
                                                      snapshot.data!['current']['wind_kph'].toString() + "km/h",
                                                      style: TextStyle(
                                                        color: Colors.black,
                                                        fontSize: 12,
                                                        fontWeight: FontWeight.w400,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                            Text(
                                              snapshot.data!['current']['wind_dir'].toString(),
                                              style: TextStyle(
                                                  color: Colors.blue, fontSize: 15, fontWeight: FontWeight.bold),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                GridView.count(
                                  shrinkWrap: true,
                                  physics: NeverScrollableScrollPhysics(),
                                  crossAxisCount: 2,
                                  childAspectRatio: (1 / .5),
                                  children: [
                                    Card(
                                      child: Padding(
                                        padding: EdgeInsets.all(20.0),
                                        child: Row(
                                          children: [
                                            Icon(
                                              size: 40,
                                              Icons.water_drop,
                                              color: Colors.blue,
                                            ),
                                            SizedBox( width: 10.0 ),
                                            Column(
                                              children: [
                                                Text(
                                                  snapshot.data!['current']['humidity'].toString() + "%",
                                                  style: TextStyle(
                                                      color: Colors.black, fontSize: 15, fontWeight: FontWeight.bold),
                                                ),
                                                Text(
                                                  'Humidity',
                                                  style: TextStyle( color: Colors.black, fontSize: 10, fontWeight: FontWeight.w400,),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Card(
                                      child: Padding(
                                        padding: EdgeInsets.all(20.0),
                                        child: Row(
                                          children: [
                                            Icon(
                                              size: 40.0,
                                              WeatherIcons.celsius,
                                              color: Colors.blue,
                                            ),
                                            SizedBox( width: 10.0 ),
                                            Column(
                                              children: [
                                                Text(
                                                  snapshot.data!['current']['feelslike_c'].toString() + " C",
                                                  style: TextStyle(
                                                      color: Colors.black, fontSize: 15, fontWeight: FontWeight.bold),
                                                ),
                                                Text(
                                                  'Real Feel',
                                                  style: TextStyle( color: Colors.black, fontSize: 10, fontWeight: FontWeight.w400,),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Card(
                                      child: Padding(
                                        padding: EdgeInsets.all(20.0),
                                        child: Row(
                                          children: [
                                            Icon(
                                              size: 40,
                                              Icons.sunny,
                                              color: Colors.blue,
                                            ),
                                            SizedBox( width: 10.0 ),
                                            Column(
                                              children: [
                                                Text(
                                                  snapshot.data!['current']['uv'].toString(),
                                                  style: TextStyle(
                                                      color: Colors.black, fontSize: 15, fontWeight: FontWeight.bold),
                                                ),
                                                Text(
                                                  'UV',
                                                  style: TextStyle( color: Colors.black, fontSize: 10, fontWeight: FontWeight.w400,),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Card(
                                      child: Padding(
                                        padding: EdgeInsets.all(20.0),
                                        child: Row(
                                          children: [
                                            Icon(
                                              size: 40,
                                              Icons.arrow_downward,
                                              color: Colors.blue,
                                            ),
                                            SizedBox( width: 10.0 ),
                                            Column(
                                              children: [
                                                Text(
                                                  snapshot.data!['current']['pressure_mb'].toString() + " mb",
                                                  style: TextStyle(
                                                      color: Colors.black, fontSize: 15, fontWeight: FontWeight.bold),
                                                ),
                                                Text(
                                                  'Pressure',
                                                  style: TextStyle( color: Colors.black, fontSize: 10, fontWeight: FontWeight.w400,),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                Card(
                                  child: Padding(
                                    padding: EdgeInsets.all(20.0),
                                    child: Column(
                                      children: [
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              'Sunrise',
                                              style: TextStyle(
                                                  color: Colors.black, fontSize: 15, fontWeight: FontWeight.bold),
                                            ),
                                            Text(
                                              snapshot.data!['forecast']['forecastday'][0]['astro']['sunrise'].toString(),
                                              style: TextStyle(
                                                  color: Colors.black, fontSize: 12, fontWeight: FontWeight.w400),
                                            ),
                                          ],
                                        ),
                                        SizedBox( height: 20.0 ),
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              'Sunset',
                                              style: TextStyle(
                                                  color: Colors.black, fontSize: 15, fontWeight: FontWeight.bold),
                                            ),
                                            Text(
                                              snapshot.data!['forecast']['forecastday'][0]['astro']['sunset'].toString(),
                                              style: TextStyle(
                                                  color: Colors.black, fontSize: 12, fontWeight: FontWeight.w400),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        }
                        return Center(
                          child: CircularProgressIndicator(
                            color: Colors.blue,
                          ),
                        );
                      }),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<List> getForecastHourData() async {
    final userCity = await SessionManager().getUserCity();
    final urlParams = ApiConstants().getNewCityParams(userCity);
    final weatherurl = ApiConstants.baseUrl + urlParams;
    final ApiResponse = await http.get(Uri.parse(weatherurl));
    final responsedata = json.decode(ApiResponse.body);
    final currentForecastData = responsedata['forecast'];
    final forecastDay = currentForecastData['forecastday'];
    print(weatherurl);
    return forecastDay;
  }

  Future getWeatherDetails() async {
    final userCity = await SessionManager().getUserCity();
    final urlParams = ApiConstants().getNewCityParams(userCity);
    final weatherurl = ApiConstants.baseUrl + urlParams;
    final ApiResponse = await http.get(Uri.parse(weatherurl));
    final responsedata = json.decode(ApiResponse.body);
    return responsedata;
  }
}
