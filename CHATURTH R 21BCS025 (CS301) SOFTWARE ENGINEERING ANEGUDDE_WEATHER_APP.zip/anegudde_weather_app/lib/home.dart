import 'dart:convert';

import 'package:annegudde_weather_app/ApiConstants.dart';
import 'package:annegudde_weather_app/about.dart';
import 'package:annegudde_weather_app/forecast.dart';
import 'package:annegudde_weather_app/login.dart';
import 'package:annegudde_weather_app/models/CurrentWeatherModel.dart';
import 'package:annegudde_weather_app/models/ForecastDayModel.dart';
import 'package:annegudde_weather_app/models/user.dart';
import 'package:annegudde_weather_app/newcity.dart';
import 'package:annegudde_weather_app/news.dart';
import 'package:annegudde_weather_app/setting.dart';
import 'package:annegudde_weather_app/shared_prefs.dart';
import 'package:annegudde_weather_app/weather.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:weather_icons/weather_icons.dart';
import 'package:shared_preferences/shared_preferences.dart';


class Home extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    void makeLogout() async {
      final prefs = await SharedPreferences.getInstance();
      prefs.setInt("ISLOGIN", 0);

      Navigator.push(context,
          MaterialPageRoute(builder: (context) => LoginPage()));
    }

    return MaterialApp(
      title: 'Home',
      theme: ThemeData(
          primarySwatch: Colors.blue,
          fontFamily: 'Poppins'
      ),
      home: Scaffold(
        body: HomePage(),
        appBar: AppBar(
          title: Text('Home'),
        ),
        bottomNavigationBar: BottomNavigationBar(
          items: <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: Icon(Icons.add_location),
              label: 'New City',
            ),
            BottomNavigationBarItem(
                icon: Icon(Icons.info, color: Colors.blue), label: 'News'),
            BottomNavigationBarItem(
                icon: Icon(
                  Icons.settings,
                  color: Colors.blue,
                ),
                label: 'Setting'),
          ],
          onTap: (int index) {
            switch (index) {
              case 0:
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => Newcity()));
                break;
              case 1:
                Navigator.push(
                    context, MaterialPageRoute(builder: (context) => News()));
                break;
              case 2:
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => Setting()));
                break;
            }
          },
        ),
        drawer: Drawer(
          child: ListView(
            children: [
              DrawerHeader(
                decoration: BoxDecoration(
                  image: DecorationImage(
                      fit: BoxFit.fill, image: AssetImage('header.jpg')),
                ),
                child: FutureBuilder(
                  future: getUserData(),
                  builder: (context, snapshot) {
                    if(snapshot.hasData){
                      return ListView(
                        children: [
                          Container(
                            height: 70,
                            margin: EdgeInsets.only(top: 15.0),
                            child: Image.asset('useraccount.png'),
                            alignment: Alignment.bottomLeft,
                          ),
                          ListTile(
                            title: Text(snapshot.data!.name,
                                style: TextStyle(
                                  color: Colors.white,
                                )),
                            subtitle: Text(
                              snapshot.data!.email,
                              style: TextStyle(
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ],
                      );
                    }
                    return Container();
                  },
                ),
              ),
              ListTile(
                title: Text('About Project'),
                leading: Icon(Icons.info),
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => About()));
                },
              ),
              ListTile(
                title: Text('New City'),
                leading: Icon(Icons.add_road),
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Newcity()));
                },
              ),
              ListTile(
                title: Text('News'),
                leading: Icon(Icons.info),
                onTap: () {
                  Navigator.push(
                      context, MaterialPageRoute(builder: (context) => News()));
                },
              ),
              ListTile(
                title: Text('Forecast'),
                leading: Icon(Icons.analytics_outlined),
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Forecast()));
                },
              ),
              ListTile(
                title: Text('Setting'),
                leading: Icon(Icons.settings),
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Setting()));
                },
              ),
              ListTile(
                title: Text('Log Out'),
                leading: Icon(Icons.logout),
                onTap: () {
                  makeLogout();
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return HomePageState();
  }
}

class HomePageState extends State<HomePage> {
  late CurrentWeatherData currentweather;
  late dynamic ApiResponse;

  String cityName = '';

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    print('InitState method called..');
    // currentweather=getTodaysWeather() as CurrentWeatherData;
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        SingleChildScrollView(
          child: Container(
            // margin: EdgeInsets.all(5.0),
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
              color: Colors.black87,
            ),
            child: Column(
              children: [
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.60,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "    Next 3 Days",
                      textAlign: TextAlign.left,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    SizedBox(),
                    TextButton(
                      onPressed: () {},
                      child: Text("7 Days  >"),
                    ),
                  ],
                ),
                SingleChildScrollView(
                  child: Container(
                    child: FutureBuilder(
                      builder: (BuildContext Context, snapshot) {
                        if (snapshot.connectionState == ConnectionState.waiting) {
                          return Center(
                            child: CircularProgressIndicator(),
                          );
                        } else if (snapshot.hasData) {
                          return Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: getDayDataColumns(snapshot.data),
                          );
                        }
                        return Center(
                          child: CircularProgressIndicator(),
                        );
                      },
                      future: getForcastData(),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),


        Container(
          height: MediaQuery.of(context).size.height * 0.60,
          width: MediaQuery.of(context).size.width,
          decoration: BoxDecoration(
            color: Colors.blue,
            borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(50.0),
              bottomRight: Radius.circular(50.0),
            ),
          ),
          child: FutureBuilder(
              future: getTodaysWeather(),
              builder: (context, AsyncSnapshot<CurrentWeatherData> snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(
                    child: CircularProgressIndicator(
                      color: Colors.white,
                    ),
                  );
                } else if (snapshot.hasData) {
                  return Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.location_on_outlined, color: Colors.white),
                          Text(
                            cityName,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20.0,
                            ),
                          )
                        ],
                      ),
                      // SizedBox(
                      //   height: 25,
                      // ),
                      Container(
                        height: 150,
                        width: 150,
                        decoration: BoxDecoration(
                          color: Colors.blue,
                        ),
                        child: Expanded(
                          child: FittedBox(
                            fit: BoxFit.fill,
                            child: Image.network(
                                "https:" + snapshot.data!.condition['icon']),
                          ),
                        ),
                      ),
                      // SizedBox(
                      //   height: 25,
                      // ),
                      Container(
                        child: Text(
                          snapshot.data!.temp_c.toString(),
                          style: TextStyle(
                            fontSize: 70,
                            color: Colors.white,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ),
                      // SizedBox(
                      //   height: 5,
                      // ),
                      Container(
                        child: Text(
                          snapshot.data!.condition['text'],
                          style: TextStyle(
                            fontSize: 25,
                            color: Colors.white,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ),
                      // SizedBox(
                      //   height: 5,
                      // ),
                      Container(
                        child: Text(
                          DateFormat.yMMMMd().format(DateTime.now()),
                          style: TextStyle(
                            fontSize: 15,
                            color: Colors.white60,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ),
                      // SizedBox(
                      //   height: 5,
                      // ),
                      Divider(
                        color: Colors.white,
                      ),
                      // SizedBox(
                      //   height: 5,
                      // ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Column(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Icon(
                                WeatherIcons.wind_beaufort_0,
                                color: Colors.white70,
                              ),
                              SizedBox(
                                height: 4,
                              ),
                              Text(
                                snapshot.data!.wind_kph.toString(),
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w500,
                                  fontSize: 13,
                                ),
                              ),
                              Text(
                                "Wind",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w300,
                                  fontSize: 10,
                                ),
                              ),
                            ],
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Icon(
                                WeatherIcons.humidity,
                                color: Colors.white70,
                              ),
                              SizedBox(
                                height: 5,
                              ),
                              Text(
                                snapshot.data!.humidity.toString(),
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w500,
                                  fontSize: 13,
                                ),
                              ),
                              Text(
                                "Humidity",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w300,
                                  fontSize: 10,
                                ),
                              ),
                            ],
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Icon(
                                WeatherIcons.cloud,
                                color: Colors.white70,
                              ),
                              SizedBox(
                                height: 4,
                              ),
                              Text(
                                snapshot.data!.cloud.toString(),
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w500,
                                  fontSize: 13,
                                ),
                              ),
                              Text(
                                "Cloud",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w300,
                                  fontSize: 10,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  );
                }

                return Container(
                  child: Center(
                    child: CircularProgressIndicator(
                      color: Colors.white,
                    ),
                  ),
                );
              }),
        ),
      ],
    );
  }

  Future<CurrentWeatherData> getTodaysWeather() async {
    final userCity = await SessionManager().getUserCity();
    final urlParams = ApiConstants().getNewCityParams(userCity);
    final weatherurl = ApiConstants.baseUrl + urlParams;
    ApiResponse = await http.get(Uri.parse(weatherurl));
    final responsedata = json.decode(ApiResponse.body);
    cityName = responsedata['location']['name'];
    final currentData = responsedata['current'];
    // print(currentData);
    currentweather = CurrentWeatherData.fromJson(currentData);
    // getForcastData();
    return currentweather;
  }

  Future<List> getForcastData() async {
    final userCity = await SessionManager().getUserCity();
    final urlParams = ApiConstants().getNewCityParams(userCity);
    final weatherurl = ApiConstants.baseUrl + urlParams;
    ApiResponse = await http.get(Uri.parse(weatherurl));
    final responsedata = json.decode(ApiResponse.body);
    final currentForecastData = responsedata['forecast'];
    final forecastDay = currentForecastData['forecastday'];
    // print(forecastDay);
    return forecastDay;
  }
}

Future<User> getUserData() async {
  User user = await SessionManager().getUserData();
  return user;
}

List<Widget> getDayDataColumns(data) {
  List forcastdaymodel = data;
  print(forcastdaymodel.length);
  List<Widget> daysweather = [];


  for (int i = 0; i < forcastdaymodel.length; i++) {
    List currentdayhour=forcastdaymodel[i]["hour"];
    final currentforecastdata = ForecastDayData.fromJson(currentdayhour[0]);
    daysweather.add(
      Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          // Icon(Icons.add_road,color: Colors.white,),
          Image.network(
            "https:" + currentforecastdata.condition['icon'],
            color: Colors.white,
          ),
          Text(
              currentforecastdata.temp_c.toString(),

            style: TextStyle(
                color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold),
          ),
          Text(
          currentforecastdata.condition["text"],

            style: TextStyle(
              color: Colors.white,

              fontSize: 10,
              fontWeight: FontWeight.w200,
            ),
          ),
        ],
      ),
    );
  }
  return daysweather;
}
