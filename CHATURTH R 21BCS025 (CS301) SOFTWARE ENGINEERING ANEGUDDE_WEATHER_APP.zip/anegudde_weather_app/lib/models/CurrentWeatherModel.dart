class CurrentWeatherData{
  final double temp_c;
  final double wind_kph;
  final int humidity;
  final int cloud;
  final double vis_km;
  final Map<String,dynamic> condition;
  final String today;

  const CurrentWeatherData({
    required this.temp_c,
    required this.wind_kph,
    required this.humidity,
    required this.cloud,
    required this.vis_km,
    required this.condition,
    required this.today,
  });

  factory CurrentWeatherData.fromJson(Map<String,dynamic> json){
   return CurrentWeatherData(
       temp_c : json['temp_c'],
       wind_kph : json['wind_kph'],
       humidity : json['humidity'],
       cloud: json['cloud'],
      vis_km: json['vis_km'],
     condition: json['condition'],
     today: json['last_updated'],
   );
  }
}