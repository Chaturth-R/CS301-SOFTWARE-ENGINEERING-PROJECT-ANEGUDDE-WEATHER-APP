class User{
  final String name;
  final String email;
  final String phone;
  final String password;
  final String address;
  final String city;

  const User({
    required this.name,
    required this.email,
    required this.phone,
    required this.password,
    required this.address,
    required this.city,
  });

  factory User.fromJson(Map<String,dynamic> json){
    return User(
      name : json['name'],
      email : json['email'],
      phone : json['phone'],
      password: json['password'],
      address: json['address'],
      city: json['city'],
    );
  }

  Map<String,dynamic> toJson() {
    var json = new Map<String, dynamic>();
    json['name'] = name;
    json['email'] = email;
    json['phone'] = phone;
    json['password'] = password;
    json['address'] = address;
    json['city'] = city;

    return json;
  }
}