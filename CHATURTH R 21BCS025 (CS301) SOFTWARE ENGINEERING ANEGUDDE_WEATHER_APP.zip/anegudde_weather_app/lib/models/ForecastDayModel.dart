class ForecastDayData{
  final double temp_c;
  final double wind_kph;
  final int humidity;
  final double vis_km;
  final Map<String,dynamic> condition;
  final String today;
  final int cloud;

  ForecastDayData({
    required this.temp_c,
    required this.wind_kph,
    required this.humidity,
    required this.vis_km,
    required this.condition,
    required this.today,
    required this.cloud}
    );

  factory ForecastDayData.fromJson(Map<String , dynamic> json) {
    return ForecastDayData(
      temp_c: json["temp_c"],
      wind_kph: json["wind_kph"],
      humidity: json["humidity"],
      vis_km: json["vis_km"],
      condition: json["condition"],
      today: json["time"],
      cloud: json["cloud"],

    );
  }

}