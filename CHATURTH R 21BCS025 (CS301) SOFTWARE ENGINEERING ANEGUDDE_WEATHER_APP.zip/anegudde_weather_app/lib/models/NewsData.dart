class NewsData{
  final String imageUrl;
  final String title;
  final String description;
  final String sourceUrl;
  final String date;

  const NewsData({
    required this.imageUrl,
    required this.title,
    required this.description,
    required this.sourceUrl,
    required this.date,
  });

  factory NewsData.fromJson(Map<String,dynamic> json){
    return NewsData(
      imageUrl : json['imageUrl'],
      title : json['title'],
      description : json['description'],
      sourceUrl: json['sourceUrl'],
      date: json['date'],
    );
  }
}