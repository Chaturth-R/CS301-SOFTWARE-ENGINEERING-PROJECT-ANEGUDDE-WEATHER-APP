import 'dart:convert';

import 'models/user.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SessionManager{
  Future<User> getUserData() async {
    final prefs = await SharedPreferences.getInstance();

    Map<String,dynamic> userMap = json.decode(prefs.getString("USER")!) as Map<String, dynamic>;
    User user = User.fromJson(userMap);

    return user;
  }

  Future<String> getUserCity() async {
    User user = await getUserData();
    String userCity = user.city;
    return userCity;
  }
}