import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class About extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'About',
      home: AboutPage(),
      theme: ThemeData(
          primarySwatch: Colors.blue,
          fontFamily: 'Poppins'
      ),
    );
  }
}

class AboutPage extends StatefulWidget {
  const AboutPage({Key? key}) : super(key: key);

  @override
  State<AboutPage> createState() => _AboutPageState();
}

class _AboutPageState extends State<AboutPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'About',
          style: TextStyle(
            fontSize: 15.0,
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text(
                'Anegudde Weather App',
                style: TextStyle(
                    color: Colors.blue, fontSize: 22, fontWeight: FontWeight.w400),
              ),
              SizedBox(height: 20.0),
              Text(
                'Anegudde Weather App is an innovative weather app that utilizes a weather API to display current and forecasted weather information, weather news and weather videos. It has been designed with scalability, security and SMART goals in mind.',
                style: TextStyle(
                    color: Colors.black, fontSize: 14),
              ),
              SizedBox(height: 10.0),
              Text(
                'The app has been developed using Flutter, a free and open-source UI software development kit created by Google and is used to develop applications for Android, iOS, Windows, Mac, Linux, Google Fuchsia and the web..',
                style: TextStyle(
                    color: Colors.black, fontSize: 14),
              ),
              SizedBox(height: 30.0),
              Table(
                children: [
                  TableRow(children: [
                    Text(
                      'INSTITUTE NAME',
                      style: TextStyle(
                          color: Colors.black, fontSize: 14, fontWeight: FontWeight.w600),
                    ),
                    Text(
                      'INDIAN INSTITUTE OF INFORMATION TECHNOLOGY, DHARWAD (IIITDWD)',
                      style: TextStyle(
                          color: Colors.black, fontSize: 14, fontWeight: FontWeight.w400),
                    ),
                  ]),
                  TableRow(children: [ SizedBox(height: 10.0), SizedBox(height: 10.0) ]),
                  TableRow(children: [
                    Text(
                      'Course',
                      style: TextStyle(
                          color: Colors.black, fontSize: 14, fontWeight: FontWeight.w600),
                    ),
                    Text(
                      'Software Engineering - CS301',
                      style: TextStyle(
                          color: Colors.black, fontSize: 14, fontWeight: FontWeight.w400),
                    ),
                  ]),
                  TableRow(children: [ SizedBox(height: 10.0), SizedBox(height: 10.0) ]),
                  TableRow(children: [
                    Text(
                      'NAME',
                      style: TextStyle(
                          color: Colors.black, fontSize: 14, fontWeight: FontWeight.w600),
                    ),
                    Text(
                      'CHATURTH R',
                      style: TextStyle(
                          color: Colors.black, fontSize: 14, fontWeight: FontWeight.w400),
                    ),
                  ]),
                  TableRow(children: [ SizedBox(height: 10.0), SizedBox(height: 10.0) ]),
                  TableRow(children: [
                    Text(
                      'ROLL NO',
                      style: TextStyle(
                          color: Colors.black, fontSize: 14, fontWeight: FontWeight.w600),
                    ),
                    Text(
                      '21BCS025',
                      style: TextStyle(
                          color: Colors.black, fontSize: 14, fontWeight: FontWeight.w400),
                    ),
                  ]),
                  TableRow(children: [ SizedBox(height: 10.0), SizedBox(height: 10.0) ]),
                  TableRow(children: [
                    Text(
                      'CLASS',
                      style: TextStyle(
                          color: Colors.black, fontSize: 14, fontWeight: FontWeight.w600),
                    ),
                    Text(
                      '4TH SEM CSE SEC A',
                      style: TextStyle(
                          color: Colors.black, fontSize: 14, fontWeight: FontWeight.w400),
                    ),
                  ]),
                  TableRow(children: [ SizedBox(height: 10.0), SizedBox(height: 10.0) ]),
                  TableRow(children: [
                    Text(
                      'GITHUB PROJECT',
                      style: TextStyle(
                          color: Colors.black, fontSize: 14, fontWeight: FontWeight.w600),
                    ),
                    InkWell(
                      onTap: () => viewMoreAction('https://github.com/Chaturth-R/CS301-SOFTWARE-ENGINEERING-PROJECT-ANEGUDDE-WEATHER-APP'),
                      child: Text(
                        'Open Github',
                        style: TextStyle(color: Colors.blue),
                      ),
                    ),
                  ]),
                ],
              ),
              SizedBox(height: 30.0),
            ],
          ),
        ),
      ),
    );
  }

  viewMoreAction(String url) async {
    final uri = Uri.parse(url);
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }
}
