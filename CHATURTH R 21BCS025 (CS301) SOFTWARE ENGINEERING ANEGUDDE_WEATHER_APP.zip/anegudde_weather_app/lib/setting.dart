import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:annegudde_weather_app/home.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:annegudde_weather_app/models/user.dart';

class Setting extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Setting',
      home: SettingPage(),
    );
  }
}

class SettingPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return SettingPageState();
  }
}

class SettingPageState extends State<SettingPage> {
  final namecontrol=TextEditingController();
  final contactcontrol=TextEditingController();
  final passwordcontrol=TextEditingController();
  final mailcontrol=TextEditingController();
  final addresscontrol=TextEditingController();
  final citycontrol=TextEditingController();

  final formkey = GlobalKey<FormState>();

  setUserInfo() async {
    final prefs = await SharedPreferences.getInstance();
    Map<String,dynamic> userMap = json.decode(prefs.getString("USER")!) as Map<String, dynamic>;
    User user = User.fromJson(userMap);

    namecontrol.text = user.name;
    contactcontrol.text = user.phone;
    passwordcontrol.text = user.password;
    mailcontrol.text = user.email;
    addresscontrol.text = user.address;
    citycontrol.text = user.city;
  }

  saveUser() async {
    final prefs = await SharedPreferences.getInstance();

    User user = User(
        name: namecontrol.text,
        email: mailcontrol.text,
        phone: contactcontrol.text,
        password: passwordcontrol.text,
        address: addresscontrol.text,
        city: citycontrol.text
    );
    Map<String,dynamic> userMap = user.toJson();
    prefs.setString("USER", json.encode(userMap));

    // showToast(context);

    Navigator.push(context,
        MaterialPageRoute(builder: (context) => Home()));
  }

  @override
  void initState() {
    super.initState();
    setUserInfo();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Setting'),
      ),
      body: Form(
        key: formkey,
        child: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                margin: EdgeInsets.all(5.0),
                child: TextFormField(
                  controller: namecontrol,
                  validator: (value){
                    if(value!.isEmpty) {
                      return 'Please enter Name';
                    }
                  },
                  decoration: InputDecoration(
                    hintText: 'Name',
                    prefixIcon: Icon(Icons.person),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.red,
                      ),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.all(5.0),
                child: TextFormField(
                  controller: contactcontrol,
                  validator: (value){
                    if(value!.isEmpty) {
                      return 'Please enter Contact Number';
                    }
                  },
                  decoration: InputDecoration(
                    hintText: 'Contact Number',
                    prefixIcon: Icon(Icons.phone_android_rounded),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.red,
                      ),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.all(5.0),
                child: TextFormField(
                  controller: passwordcontrol,
                  validator: (value){
                    if(value!.isEmpty) {
                      return 'Please enter Password';
                    }
                  },
                  decoration: InputDecoration(
                    hintText: 'Password',
                    prefixIcon: Icon(Icons.password),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.red,
                      ),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.all(5.0),
                child: TextFormField(
                  controller: mailcontrol,
                  validator: (value){
                    if(value!.isEmpty) {
                      return 'Please enter Email ID';
                    }
                  },
                  decoration: InputDecoration(
                    hintText: 'Email ID',
                    prefixIcon: Icon(Icons.email_outlined),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.red,
                      ),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.all(5.0),
                child: TextFormField(
                  controller: addresscontrol,
                  validator: (value){
                    if(value!.isEmpty) {
                      return 'Please enter Address';
                    }
                  },
                  decoration: InputDecoration(
                    hintText: 'Address',
                    prefixIcon: Icon(Icons.home_outlined),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.red,
                      ),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.all(5.0),
                child: TextFormField(
                  controller: citycontrol,
                  validator: (value){
                    if(value!.isEmpty) {
                      return 'Please enter City Name';
                    }
                  },
                  decoration: InputDecoration(
                    hintText: 'Home City',
                    prefixIcon: Icon(Icons.location_city_outlined),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.red,
                      ),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                  ),
                ),
              ),
              Container(
                width: double.infinity,
                height: 50,
                margin: EdgeInsets.all(5.0),
                child: ElevatedButton.icon(
                  icon: Icon(Icons.save_alt_rounded),
                  onPressed: () {
                    if(formkey.currentState!.validate()){
                      saveUser();
                    }
                  },
                  label: Text('Save'),
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void showToast(BuildContext context) {
    final scaffold = ScaffoldMessenger.of(context);
    scaffold.showSnackBar(SnackBar(
      content: Text('Successfully Updated'),
      backgroundColor: Colors.blue,
    ));
  }
}
