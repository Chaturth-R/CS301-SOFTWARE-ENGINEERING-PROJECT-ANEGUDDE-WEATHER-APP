import 'dart:convert';

import 'package:annegudde_weather_app/login.dart';
import 'package:annegudde_weather_app/models/user.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Registration extends StatelessWidget {
  final scffkey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
          primarySwatch: Colors.blue,
          fontFamily: 'Poppins'
      ),
      home: RegistrationPage(),
    );
  }
}

class RegistrationPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return Registrationstate();
  }
}

class Registrationstate extends State<RegistrationPage> {
  final scafkey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {

    final namecontrol=TextEditingController();
    final contactcontrol=TextEditingController();
    final passwordcontrol=TextEditingController();
    final mailcontrol=TextEditingController();
    final addresscontrol=TextEditingController();
    final citycontrol=TextEditingController();
    final formkey=GlobalKey<FormState>();

    void saveUser() async {
      final prefs = await SharedPreferences.getInstance();

      User user = User(
          name: namecontrol.text,
          email: mailcontrol.text,
          phone: contactcontrol.text,
          password: passwordcontrol.text,
          address: addresscontrol.text,
          city: citycontrol.text
      );
      Map<String,dynamic> userMap = user.toJson();
      prefs.setString("USER", json.encode(userMap));

      print(userMap);

      showToast(context);
    }

    return Scaffold(
      key: scafkey,
      body: SingleChildScrollView(
        child: Container(
          child: Center(
            child: Form(
              key: formkey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    margin: EdgeInsets.only(top: 30.0, bottom: 20.0,left: 5.0),
                    width: double.infinity,
                    child: Row(
                      children: [
                        ElevatedButton.icon(
                          onPressed: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>Login()));
                          },
                          icon: Icon(
                            Icons.arrow_back,
                            size: 30.0,
                          ),
                          label: Text(""),
                        ),
                        SizedBox(
                          width: 100.0,
                        ),
                        Text(
                          "Sign Up",
                          style: TextStyle(
                              color: Colors.black87,
                              fontWeight: FontWeight.bold,
                              fontSize: 20.0),
                        ),
                      ],
                    ),
                  ),
                  Divider(
                    color: Colors.black87,
                  ),
                  Container(
                    width: double.infinity,
                    child: Text(
                      'Create Your Account',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 18.0,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  Container(
                    width: double.infinity,
                    margin: EdgeInsets.all(5.0),
                    child: Text(
                      'Please provide following information to create account ',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 10.0,
                        fontWeight: FontWeight.normal,
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.all(5.0),
                    child: TextFormField(
                      controller: namecontrol,
                      validator: (value){
                        if(value!.isEmpty) {
                          return 'Please enter Name';
                        }
                      },
                      decoration: InputDecoration(
                        hintText: 'Name',
                        prefixIcon: Icon(Icons.person),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: Colors.red,
                          ),
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.all(5.0),
                    child: TextFormField(
                      controller: contactcontrol,
                      validator: (value){
                        if(value!.isEmpty) {
                          return 'Please enter Contact Number';
                        }
                      },
                      decoration: InputDecoration(
                        hintText: 'Contact Number',
                        prefixIcon: Icon(Icons.phone_android_rounded),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: Colors.red,
                          ),
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.all(5.0),
                    child: TextFormField(
                      controller: passwordcontrol,
                      validator: (value){
                        if(value!.isEmpty) {
                          return 'Please enter Password';
                        }
                      },
                      decoration: InputDecoration(
                        hintText: 'Password',
                        prefixIcon: Icon(Icons.password),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: Colors.red,
                          ),
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.all(5.0),
                    child: TextFormField(
                      controller: mailcontrol,
                      validator: (value){
                        if(value!.isEmpty) {
                          return 'Please enter Email ID';
                        }
                      },
                      decoration: InputDecoration(
                        hintText: 'Email ID',
                        prefixIcon: Icon(Icons.email_outlined),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: Colors.red,
                          ),
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.all(5.0),
                    child: TextFormField(
                      controller: addresscontrol,
                      validator: (value){
                        if(value!.isEmpty) {
                          return 'Please enter Address';
                        }
                      },
                      decoration: InputDecoration(
                        hintText: 'Address',
                        prefixIcon: Icon(Icons.home_outlined),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: Colors.red,
                          ),
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.all(5.0),
                    child: TextFormField(
                      controller: citycontrol,
                      validator: (value){
                        if(value!.isEmpty) {
                          return 'Please enter City Name';
                        }
                      },
                      decoration: InputDecoration(
                        hintText: 'Home City',
                        prefixIcon: Icon(Icons.location_city_outlined),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: Colors.red,
                          ),
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    width: double.infinity,
                    height: 50,
                    margin: EdgeInsets.all(5.0),
                    child: ElevatedButton.icon(
                      icon: Icon(Icons.save_alt_rounded),
                      onPressed: () {
                        if(formkey.currentState!.validate()){
                          saveUser();
                        }
                      },
                      label: Text('Save'),
                      style: ButtonStyle(
                        backgroundColor: MaterialStateProperty.all(Colors.blue),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 20.0,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Already have an Account..? ",
                        style: TextStyle(
                          color: Colors.black87,
                          fontWeight: FontWeight.normal,
                          fontSize: 15.0,
                        ),
                      ),
                      TextButton(onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => Login()));
                      },
                        child: Text("Log IN ",
                          style: TextStyle(
                            color: Colors.blue,
                            fontSize: 15.0,
                            fontWeight: FontWeight.normal,
                          ),
                        ),
                      )
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void showToast(BuildContext context) {
    final scaffold = ScaffoldMessenger.of(context);
    scaffold.showSnackBar(SnackBar(
      content: Text('Successfully Registered'),
      backgroundColor: Colors.blue,
    ));
  }
}
