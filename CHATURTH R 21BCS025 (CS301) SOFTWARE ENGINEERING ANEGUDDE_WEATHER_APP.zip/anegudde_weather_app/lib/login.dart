import 'dart:convert';

import 'package:annegudde_weather_app/models/user.dart';
import 'package:flutter/material.dart';
import 'package:annegudde_weather_app/registration.dart';
import 'package:annegudde_weather_app/home.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Login extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Login',
      home: LoginPage(),
      theme: ThemeData(
        primarySwatch: Colors.blue,
        fontFamily: 'Poppins'
      ),
    );
  }
}

class LoginPage extends StatefulWidget {
  @override
  State<LoginPage> createState() {
    return LoginPagestate();
  }
}

class LoginPagestate extends State<LoginPage> {
  final usercontrol = TextEditingController();
  final passcontrol = TextEditingController();
  final formkey = GlobalKey<FormState>();

  void makeLogin() async {
    final prefs = await SharedPreferences.getInstance();

    Map<String,dynamic> userMap = json.decode(prefs.getString("USER")!) as Map<String, dynamic>;
    User user = User.fromJson(userMap);

    if(usercontrol.text == user.name){
      if(passcontrol.text == user.password){
        prefs.setInt("ISLOGIN", 1);
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => Home()));
      }else{
        showToast(context, 'Invalid Login Credentials');
      }
    } else {
      showToast(context, 'User Not Found');
    }
  }

  void doSilentLogin() async {
    final prefs = await SharedPreferences.getInstance();

    if(prefs.getInt("ISLOGIN") == 1){
      Navigator.push(context,
          MaterialPageRoute(builder: (context) => Home()));
    }
  }

  @override
  void initState() {
    super.initState();
    doSilentLogin();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Form(
        key: formkey,
        child: Center(
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  margin: EdgeInsets.only(bottom: 25.0),
                  // child: CircleAvatar(
                  //   radius: 75.0,
                  //   backgroundImage: AssetImage('App_logo.jpeg'),
                  // ),
                  child: Expanded(
                    child: Image.asset('assets/anegudde-weather-logo.jpeg', width: 300,),
                  ),
                ),
                Container(
                  width: double.infinity,
                  margin: EdgeInsets.all(5.0),
                  child: Text(
                    'Sign in to your account',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15.0,
                      fontWeight: FontWeight.normal,
                      color: Colors.black87,
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.all(5.0),
                  child: TextFormField(
                    controller: usercontrol,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return "Please enter username";
                      }
                    },
                    decoration: InputDecoration(
                      hintText: 'Username',
                      prefixIcon: Icon(Icons.account_circle),
                      fillColor: Colors.blue,

                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(5.0),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.red,
                        ),
                      ),
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.all(5.0),
                  child: TextFormField(
                    validator: (value) {
                      if (value!.isEmpty) {
                        return "Pls enter password";
                      }
                    },
                    obscureText: true,
                    controller: passcontrol,
                    decoration: InputDecoration(
                      hintText: 'Password',
                      prefixIcon: Icon(Icons.password),
                      border: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.red,
                        ),
                        borderRadius: BorderRadius.circular(5.0),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.red,
                        ),
                      ),
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.all(5.0),
                  width: double.infinity,
                  height: 50.0,
                  child: ElevatedButton.icon(
                    icon: Icon(Icons.login),
                    onPressed: () {
                      if (formkey.currentState!.validate()) {
                        makeLogin();
                          // Navigator.push(context,
                          //     MaterialPageRoute(builder: (context) => Home()));
                      }
                    },
                    label: Text('Login'),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "Not have an Account..? ",
                      style: TextStyle(
                        color: Colors.black87,
                        fontWeight: FontWeight.normal,
                        fontSize: 15.0,
                      ),
                    ),
                    TextButton(onPressed: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => Registration()));
                    },
                        child: Text("Click HERE ",
                        style: TextStyle(
                          color: Colors.blue,
                          fontSize: 15.0,
                          fontWeight: FontWeight.normal,
                        ),
                        ),
                    )
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void showToast(BuildContext context, String message) {
    final scaffold = ScaffoldMessenger.of(context);
    scaffold.showSnackBar(SnackBar(
      content: Text(message),
      backgroundColor: Colors.blue,
    ));
  }
}
