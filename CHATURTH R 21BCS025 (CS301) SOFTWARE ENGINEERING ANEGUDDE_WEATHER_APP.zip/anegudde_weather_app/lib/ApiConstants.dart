class ApiConstants{
  static final String baseUrl='http://api.weatherapi.com/v1/';
  static final String APIKey="4e508ca1ece74b98a2365917231303";
  static final String APIParameter="forecast.json?key="+APIKey+"&q=Mangalore&aqi=no&days=7&hour=11";
  static final String HourlyAPIParameter="forecast.json?key="+APIKey+"&q=Mangalore&aqi=no&days=7";

  getNewCityParams(String city) {
    final String urlParams = "forecast.json?key="+APIKey+"&q=" + city + "&aqi=no&days=7";
    return urlParams;
  }

  getAPIParameter(String city) {
    final String urlParams = "forecast.json?key="+APIKey+"&q=" + city + "&aqi=no&days=7&hour=11";
    return urlParams;
  }

  getHourlyAPIParameter(String city){
    final String urlParams = "forecast.json?key="+APIKey+"&q=" + city + "&aqi=no&days=7";
    return urlParams;
  }

}